# Commands

- `npm run build` - build project
- `sls offline` - start project in offline mode
